package pages;

import org.openqa.selenium.*;

public class CartPage {
	
	WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    By quantityInput = By.name("quantity");
    By updateButton = By.id("update-cart");
    By removeButton = By.id("remove-item");
    By totalPrice = By.id("cart-total");

    public void updateQuantity(int qty) {
        WebElement qtyInput = driver.findElement(quantityInput);
        qtyInput.clear();
        qtyInput.sendKeys(String.valueOf(qty));
        driver.findElement(updateButton).click();
    }

    public void removeProduct() {
        driver.findElement(removeButton).click();
    }

    public boolean isCartEmpty() {
        return driver.getPageSource().contains("Your cart is empty");
    }

    public String getTotalPrice() {
        return driver.findElement(totalPrice).getText();
    }
}


