package pages;
import org.openqa.selenium.*;

	import java.util.List;

	public class SearchResultsPage {
	    WebDriver driver;

	    public SearchResultsPage(WebDriver driver) {
	        this.driver = driver;
	    }

	    By noResults = By.xpath("//input[@class='a-size-medium a-color-base a-text-normal'])");
	    By products = By.cssSelector(".product-list .product");

	    public boolean isNoResultsFound() {
	        return driver.findElement(noResults).isDisplayed();
	    }

	    public boolean isProductFound(String keyword) {
	        return driver.getPageSource().contains(keyword);
	    }

	    public void selectProductByIndex(int index) {
	        List<WebElement> productList = driver.findElements(products);
	        if (productList.size() > index) {
	            productList.get(index).click();
	        }
	    }
	}

