package tests;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import pages.*;
import utils.DriverFactory;


public class EcommerceTests {
	 WebDriver driver;
	    HomePage home;
	    SearchResultsPage results;
	    CartPage cart;

	    @BeforeClass
	    public void setup() {
	        driver = DriverFactory.quitDriver();
	        driver.get("https://www.amazon.in/"); 
	        home = new HomePage(driver);
	        results = new SearchResultsPage(driver);
	        cart = new CartPage(driver);
	    }

	    @Test(priority = 1)
	    public void testSearchNonExistingProduct() {
	        home.search("ld345tsxslfer");
	        assert results.isNoResultsFound();
	    }

	    @Test(priority = 2)
	    public void testSearchExistingProduct() {
	        home.search("Laptop");
	        assert results.isProductFound("Laptop");
	    }

	    @Test(priority = 3)
	    public void testAddProductToCart() {
	        results.selectProductByIndex(3);
	        // assume it redirects to ProductPage with "Add to Cart" logic handled
	    }

	    @Test(priority = 4)
	    public void testUpdateCartQuantity() {
	        cart.updateQuantity(2);
	        // Add validation logic here for updated quantity & price
	    }

	    @Test(priority = 5)
	    public void testRemoveProductFromCart() {
	        cart.removeProduct();
	        assert cart.isCartEmpty();
	    }

	    @AfterClass
	    public void tearDown() {
	        DriverFactory.quitDriver();
	    }

}
